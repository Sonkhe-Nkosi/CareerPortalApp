package com.example.mycareerportalapp

import NavigationSystem
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.mycareerportalapp.ui.theme.MyCareerPortalAppTheme
import com.google.firebase.FirebaseApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        FirebaseApp.initializeApp(this)

        setContent {
            MyCareerPortalAppTheme {

                NavigationSystem(start = "LoadingScreen")
            }
        }
    }
}
