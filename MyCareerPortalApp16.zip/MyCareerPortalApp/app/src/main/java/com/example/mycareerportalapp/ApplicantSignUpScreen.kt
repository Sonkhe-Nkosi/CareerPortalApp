package com.example.mycareerportalapp

import android.annotation.SuppressLint
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun ApplicantSignUpScreen(navController: NavController) {
    Scaffold(
        topBar = { ApplicantTopBar() },
        content = {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 100.dp)
            ) {
                item {
                    ApplicantSignUpForm(navController)
                }
            }
        }
    )
}

@Composable
fun ApplicantTopBar() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(240, 240, 241, 255))
            .padding(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
        ) {
            Image(
                painter = painterResource(id = R.drawable.logo), // Replace with your logo resource
                contentDescription = "Logo",
                modifier = Modifier.size(50.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "University of Mpumalanga Applicants:",
                style = MaterialTheme.typography.titleLarge,
                color = Color(2, 24, 100, 255)
            )
        }
    }
}

@Composable
fun ApplicantSignUpForm(navController: NavController) {
    var fullName by remember { mutableStateOf("") }
    var emailAddress by remember { mutableStateOf("") }
    var contactNumber by remember { mutableStateOf("") }
    var nationality by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var acceptTerms by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current

    Column(
        modifier = Modifier.fillMaxWidth()
    ) {
        Spacer(modifier = Modifier.height(16.dp))
        TextField(
            value = fullName,
            onValueChange = { fullName = it },
            label = { Text("Full Name") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        TextField(
            value = emailAddress,
            onValueChange = { emailAddress = it },
            label = { Text("Email Address") },
            keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Email),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        Modifier.fillMaxWidth().DateOfBirthPicker(
            dateOfBirth = remember { mutableStateOf("Year / Month / Day") },
        )
        Spacer(modifier = Modifier.height(16.dp))
        TextField(
            value = contactNumber,
            onValueChange = { contactNumber = it },
            label = { Text("Contact Number") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        TextField(
            value = nationality,
            onValueChange = { nationality = it },
            label = { Text("Nationality") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        TextField(
            value = address,
            onValueChange = { address = it },
            label = { Text("Address") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        TextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        TextField(
            value = confirmPassword,
            onValueChange = { confirmPassword = it },
            label = { Text("Confirm Password") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))

        // Disclaimer message
        Text(
            text = "By signing up, you agree to our Terms and Conditions",
            style = MaterialTheme.typography.bodySmall,
            color = Color.Gray,
            textAlign = TextAlign.Start
        )
        Spacer(modifier = Modifier.height(16.dp))

        // Checkbox to accept terms and conditions
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = acceptTerms,
                onCheckedChange = { acceptTerms = it },
                colors = CheckboxDefaults.colors(checkedColor = Color(2, 24, 100, 255))
            )
            Text(
                text = "I accept the terms and conditions",
                style = MaterialTheme.typography.bodySmall
            )
        }
        Spacer(modifier = Modifier.height(16.dp))

        ApplicantCustomButton(
            text = "Sign Up",
            onClick = {
                if (password == confirmPassword) {
                    ApplicantSignUp(
                        navController,
                        emailAddress,
                        password,
                        setError = { errorMessage = it })
                } else {
                    Toast.makeText(context, "Passwords do not match", Toast.LENGTH_SHORT).show()
                }
            },
            navController = navController,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
                .height(50.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Cancel button
        TextButton(
            onClick = { navController.popBackStack() },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Cancel")
        }
    }
}

@Composable
fun ApplicantCustomButton(
    text: String,
    onClick: () -> Unit,
    navController: NavController? = null,
    destination: String? = null,
    modifier: Modifier = Modifier,
    width: Dp = ButtonDefaults.MinWidth,
    height: Dp = ButtonDefaults.MinHeight,
    isGoToChatButton: Boolean = false
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val indication = rememberRipple()

    Box(
        modifier = modifier
            .width(width)
            .height(height)
            .background(
                if (isPressed) Color(16, 105, 201, 255) else Color(2, 24, 100, 255),
                RoundedCornerShape(8.dp)
            )
            .clickable(
                indication = indication,
                interactionSource = interactionSource
            ) {
                if (isGoToChatButton) {
                    // Handle special behavior for Go To Chat button
                    onClick()
                } else {
                    destination?.let {
                        navController?.navigate(it)
                    }
                    onClick()
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = Color.White,
            style = MaterialTheme.typography.labelSmall
        )
    }
}

@Composable
fun Modifier.DateOfBirthPicker(
    dateOfBirth: MutableState<String>
) {
    // Implement your date picker logic here
    TextField(
        value = dateOfBirth.value,
        onValueChange = { dateOfBirth.value = it },
        label = { Text("Date of Birth") },
        modifier = this
    )
}

private fun ApplicantSignUp(
    navController: NavController,
    email: String,
    password: String,
    setError: (String?) -> Unit
) {
    FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, password)
        .addOnCompleteListener { task ->
            if (task.isSuccessful) {
                // Sign up success
                navController.navigate("ApplicantLoginScreen")
            } else {
                // If sign up fails, handle the error
                val error = task.exception?.message ?: "Unknown error"
                setError(error)
            }
        }
}
