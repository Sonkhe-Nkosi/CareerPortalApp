package com.example.mycareerportalapp

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun PostingScreenAdmin(navController: NavController) {
    var selectedFileUri by remember { mutableStateOf<Uri?>(null) }
    val context = navController.context

    // File picker launcher
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent(),
        onResult = { uri ->
            if (uri != null) {
                selectedFileUri = uri
            } else {
                Toast.makeText(context, "No file selected", Toast.LENGTH_SHORT).show()
            }
        }
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        // Top bar with logo and title
        AdminPostingTopBar()

        // Main content
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            var jobTitle by remember { mutableStateOf("") }
            var companyName by remember { mutableStateOf("") }
            var jobDescription by remember { mutableStateOf("") }
            var jobRequirements by remember { mutableStateOf("") }
            var jobLocation by remember { mutableStateOf("") }

            // Job Title
            TextField(
                value = jobTitle,
                onValueChange = { jobTitle = it },
                label = { Text("Job Title") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Company Name
            TextField(
                value = companyName,
                onValueChange = { companyName = it },
                label = { Text("Company Name") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Job Description
            TextField(
                value = jobDescription,
                onValueChange = { jobDescription = it },
                label = { Text("Job Description") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Job Requirements
            TextField(
                value = jobRequirements,
                onValueChange = { jobRequirements = it },
                label = { Text("Job Requirements") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Job Location
            TextField(
                value = jobLocation,
                onValueChange = { jobLocation = it },
                label = { Text("Job Location") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            // File upload button
            CustomButton(
                text = "Upload File",
                onClick = { filePickerLauncher.launch("*/*") },
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Spacer(modifier = Modifier.height(16.dp))
            // Show selected file name
            selectedFileUri?.let { uri ->
                Text(
                    text = "Selected file: ${uri.path}",
                    color = Color.Gray
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Submit button
            CustomButton(
                text = "Submit",
                onClick = {
                    selectedFileUri?.let { uri -> uploadFile(uri, context, navController) }
                },
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
        }
    }
}

@Composable
fun AdminPostingTopBar() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(240, 240, 241, 255))
            .padding(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
        ) {
            Image(
                painter = painterResource(id = R.drawable.logo), // Replace with your logo resource
                contentDescription = "Logo",
                modifier = Modifier.size(50.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "University of Mpumalanga Applicants:",
                style = MaterialTheme.typography.titleMedium,
                color = Color(2, 24, 100, 255)
            )
        }
    }
}

