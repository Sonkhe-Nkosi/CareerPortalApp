import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.mycareerportalapp.AboutAppScreen
import com.example.mycareerportalapp.AcademicInformationScreen
import com.example.mycareerportalapp.AdminDashboardScreen
import com.example.mycareerportalapp.AdminLoginScreen
import com.example.mycareerportalapp.AdminSignUpScreen
import com.example.mycareerportalapp.AlumniEmployerLoginScreen
import com.example.mycareerportalapp.AlumniEmployerSignUpScreen
import com.example.mycareerportalapp.ApplicantDashboardScreen
import com.example.mycareerportalapp.ApplicantLoginScreen
import com.example.mycareerportalapp.ApplicantSignUpScreen
import com.example.mycareerportalapp.ApsCalculatorScreen
import com.example.mycareerportalapp.BursaryPostingScreen
import com.example.mycareerportalapp.CareerGuidanceScreen
import com.example.mycareerportalapp.ChatScreen
import com.example.mycareerportalapp.DiscoverCoursesScreen
import com.example.mycareerportalapp.ForgotPasswordScreen
import com.example.mycareerportalapp.GeneralSettingsScreen
import com.example.mycareerportalapp.HomeScreen
import com.example.mycareerportalapp.InternPostingTopBar
import com.example.mycareerportalapp.InternshipPostingScreen
import com.example.mycareerportalapp.JobPostingScreen
import com.example.mycareerportalapp.LearnershipPostingScreen
import com.example.mycareerportalapp.LoadingScreen
import com.example.mycareerportalapp.LogoutScreen
import com.example.mycareerportalapp.MyProfileScreen
import com.example.mycareerportalapp.NotificationScreen

import com.example.mycareerportalapp.SearchFAQsScreen
import com.example.mycareerportalapp.SecurityAndPrivacyScreen
import com.example.mycareerportalapp.SettingsScreen
import com.example.mycareerportalapp.SkillsAndInterestsScreen
import com.example.mycareerportalapp.StudentGraduatesLoginScreen
import com.example.mycareerportalapp.StudentGraduatesSignUpScreen
import com.example.mycareerportalapp.UpdatePostingScreen
import com.example.mycareerportalapp.UploadResumeScreen
import com.example.mycareerportalapp.bursaryPost
import com.example.mycareerportalapp.internshipPost
import com.example.mycareerportalapp.learnershipPost
import com.example.mycareerportalapp.updatePost

@Composable
fun NavigationSystem(start: String) {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = start) {
        composable("ApplicantLoginScreen") {
            ApplicantLoginScreen(navController = navController)
        }
        composable("LearnershipPostingScreen") {
            LearnershipPostingScreen(navController = navController)
        }
        composable("ApplicantSignUpScreen") {
            ApplicantSignUpScreen(navController = navController)
        }
        composable("HomeScreen") {
            HomeScreen(navController = navController)
        }
        composable("LoadingScreen") {
            LoadingScreen(navController = navController)
        }
        composable("ApplicantDashboardScreen") {
            ApplicantDashboardScreen(navController = navController)
        }
        composable("AdminLoginScreen") {
            AdminLoginScreen(navController = navController)
        }
        composable("AdminSignUpScreen") {
            AdminSignUpScreen(navController = navController)
        }
        composable("StudentGraduatesLoginScreen") {
            StudentGraduatesLoginScreen(navController = navController)
        }
        composable("StudentGraduatesSignUpScreen") {
            StudentGraduatesSignUpScreen(navController = navController)
        }
        composable("AlumniEmployerLoginScreen") {
            AlumniEmployerLoginScreen(navController = navController)
        }
        composable("AlumniEmployerSignUpScreen") {
            AlumniEmployerSignUpScreen(navController = navController)
        }
        composable("UpdatePostingScreen") {
            UpdatePostingScreen(navController = navController)
        }
        composable("ApsCalculatorScreen") {
            ApsCalculatorScreen(navController = navController)
        }
        composable("AdminDashboardScreen") {
            var newLearnershipPosts = listOf<learnershipPost>()
            var newBursaryPosts = listOf<bursaryPost>()
            var newInternshipPosts = listOf<internshipPost>()
            var newUpdatePosts = listOf<updatePost>()
            AdminDashboardScreen(navController = navController)
        }
        composable("JobPostingScreen") {
            JobPostingScreen(navController = navController)
        }
        composable("ChatScreen") {
            ChatScreen(navController = navController)
        }
        composable("InternshipPostingScreen") {
            InternshipPostingScreen(navController = navController)
        }
        composable("DiscoverCoursesScreen") {
            DiscoverCoursesScreen(navController = navController)
        }
        composable("SettingsScreen") {
            SettingsScreen(navController = navController)
        }
        composable("SkillsAndInterestsScreen") {
            SkillsAndInterestsScreen(navController = navController)
        }
        composable("AcademicInformationScreen") {
            AcademicInformationScreen(navController = navController)
        }
        composable("NotificationScreen") {
            NotificationScreen(navController = navController)
        }
        composable("UploadResumeScreen") {
            UploadResumeScreen(navController = navController)
        }
        composable("BursaryPostingScreen") {
            BursaryPostingScreen(navController = navController)
        }
        composable("SearchFAQsScreen") {
            SearchFAQsScreen(navController = navController)
        }
        composable("AboutAppScreen") {
            AboutAppScreen(navController = navController)
        }
        composable("GeneralSettingsScreen") {
            GeneralSettingsScreen(navController = navController)
        }
        composable("SecurityAndPrivacyScreen") {
            SecurityAndPrivacyScreen(navController = navController)
        }
        composable("LogoutScreen") {
            LogoutScreen(navController = navController)
        }
        composable("ForgotPasswordScreen") {
            ForgotPasswordScreen(navController = navController)
        }
        composable("CareerGuidanceScreen") {
            CareerGuidanceScreen(navController = navController)
        }
        composable("MyProfileScreen") {
            MyProfileScreen(navController = navController)
        }
    }
}
