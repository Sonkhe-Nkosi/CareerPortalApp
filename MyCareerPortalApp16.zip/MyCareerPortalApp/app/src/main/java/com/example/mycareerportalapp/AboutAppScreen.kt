package com.example.mycareerportalapp


import android.annotation.SuppressLint
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.foundation.clickable
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutAppScreen(navController: NavController) {
    Scaffold(
        topBar = { GenericTopBar(navController, "About App") },
        bottomBar = { BottomNavigationBar(navController) },
        content = { paddingValues ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp)
            ) {
                item {
                    Text(
                        "About App Content",
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.padding(vertical = 16.dp)
                    )
                }
            }
        }
    )


    @Composable
    fun PrivacyPolicyScreen() {
        Text(text = "Privacy Policy Content", modifier = Modifier.padding(16.dp))
    }

    @Composable
    fun TermsOfUseScreen() {
        Text(text = "Terms of Use Content", modifier = Modifier.padding(16.dp))
    }

    @Composable
    fun OpenSourceLibrariesScreen() {
        Text(text = "Open Source Libraries Content", modifier = Modifier.padding(16.dp))
    }


}