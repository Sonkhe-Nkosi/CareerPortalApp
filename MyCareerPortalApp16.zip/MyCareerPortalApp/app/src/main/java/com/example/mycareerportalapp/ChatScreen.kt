package com.example.mycareerportalapp

import android.annotation.SuppressLint
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.material3.AlertDialogDefaults.containerColor
import androidx.compose.material3.TopAppBarDefaults.topAppBarColors
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun ChatScreen(navController: NavController) {
    var showUsers by remember { mutableStateOf(true) }
    val users = listOf("User1", "User2", "User3") // Replace with actual user list from Firebase

    Scaffold(
        topBar = { ChatTopBar(onStartChatClick = { showUsers = true }) },
        bottomBar = { ChatBottomNavigationBar(navController = navController) },
        content = {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(8.dp)
                    .padding(top = it.calculateTopPadding(), bottom = it.calculateBottomPadding())
            ) {
                if (showUsers) {
                    UserList(users) { selectedUser ->
                        showUsers = false
                        navController.navigate("ConversationScreen/${selectedUser}")
                    }
                }
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatTopBar(onStartChatClick: () -> Unit) {
    TopAppBar(
        title = { Text("Chat") },
        actions = {
            IconButton(onClick = onStartChatClick) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Start Chat",
                    tint = Color.White
                )
            }
        },
        colors = TopAppBarDefaults.mediumTopAppBarColors(
            containerColor = Color(103, 103, 255, 255),
            titleContentColor = Color.White,
            actionIconContentColor = Color.White
        )
    )
}


@Composable
fun ChatBubble(message: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.Start
    ) {
        Box(
            modifier = Modifier
                .background(Color(0xFFE1FFC7), shape = CircleShape)
                .padding(8.dp)
        ) {
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                color = Color.Black
            )
        }
    }
}

@Composable
fun UserList(users: List<String>, onUserClick: (String) -> Unit) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .padding(8.dp)
    ) {
        items(users) { user ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .clickable { onUserClick(user) },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = user,
                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 18.sp),
                    color = Color.Black,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }
        }
    }
}

fun sendMessage(sender: String, recipient: String, message: String) {
    val db = FirebaseFirestore.getInstance()
    val chatId = getChatId(sender, recipient)

    val messageData = hashMapOf(
        "sender" to sender,
        "message" to message,
        "timestamp" to System.currentTimeMillis()
    )

    db.collection("chats").document(chatId).collection("messages")
        .add(messageData)
        .addOnSuccessListener {
            // Message sent successfully
        }
        .addOnFailureListener { e ->
            // Handle error
        }
}

fun receiveMessages(sender: String, recipient: String, onMessageReceived: (String) -> Unit) {
    val db = FirebaseFirestore.getInstance()
    val chatId = getChatId(sender, recipient)

    db.collection("chats").document(chatId).collection("messages")
        .orderBy("timestamp", Query.Direction.ASCENDING)
        .addSnapshotListener { snapshots, e ->
            if (e != null) {
                // Handle error
                return@addSnapshotListener
            }

            if (snapshots != null) {
                for (document in snapshots.documents) {
                    val message = document.getString("message") ?: ""
                    onMessageReceived(message)
                }
            }
        }
}

fun getChatId(user1: String, user2: String): String {
    return if (user1 < user2) "$user1-$user2" else "$user2-$user1"
}

@Composable
fun ConversationScreen(navController: NavController, recipient: String, sender: String = "currentUser") {
    var message by remember { mutableStateOf("") }
    var conversation by remember { mutableStateOf(listOf<String>()) }

    LaunchedEffect(Unit) {
        receiveMessages(sender, recipient) { newMessage ->
            conversation = conversation + newMessage
        }
    }

    Scaffold(
        topBar = { ChatTopBar(onStartChatClick = { navController.popBackStack() }) },
        bottomBar = { BottomNavigationBar(navController = navController) },
        content = {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(8.dp)
                    .padding(top = it.calculateTopPadding(), bottom = it.calculateBottomPadding())
            ) {
                LazyColumn(
                    modifier = Modifier.weight(1f)
                ) {
                    items(conversation) { msg ->
                        ChatBubble(msg)
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White, shape = CircleShape)
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BasicTextField(
                        value = message,
                        onValueChange = { message = it },
                        keyboardOptions = KeyboardOptions.Default.copy(
                            imeAction = ImeAction.Send
                        ),
                        keyboardActions = KeyboardActions(
                            onSend = {
                                sendMessage(sender, recipient, message)
                                conversation = conversation + message
                                message = ""
                            }
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .padding(8.dp)
                    )
                    IconButton(
                        onClick = {
                            sendMessage(sender, recipient, message)
                            conversation = conversation + message
                            message = ""
                        }
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Send",
                            tint = Color(155, 155, 243, 255)
                        )
                    }
                }
            }
        }
    )
}

@Composable
fun ChatBottomNavigationBar(navController: NavController) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color.Black, shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
            .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
    ) {
        BottomAppBar(
            content = {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(6.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        IconButton(onClick = {
                            navController.navigate("ApplicantDashboardScreen")
                        }) {
                            Icon(painter = painterResource(id = R.drawable.img_3), contentDescription = "Home")
                        }
                        Text(text = "Home", style = MaterialTheme.typography.labelMedium)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        IconButton(onClick = {
                            navController.navigate("MyProfileScreen")
                        }) {
                            Icon(painter = painterResource(id = R.drawable.img_4), contentDescription = "Profile")
                        }
                        Text(text = "Profile", style = MaterialTheme.typography.labelMedium)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        IconButton(onClick = {
                            navController.navigate("PostingScreen")
                        }) {
                            Icon(painter = painterResource(id = R.drawable.addbuttonicon), contentDescription = "Add Post")
                        }
                        Text(text = "Add", style = MaterialTheme.typography.labelMedium)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        IconButton(onClick = {
                            navController.navigate("DiscoverCoursesScreen")
                        }) {
                            Icon(painter = painterResource(id = R.drawable.img_5), contentDescription = "Courses")
                        }
                        Text(text = "Courses", style = MaterialTheme.typography.labelMedium)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        IconButton(onClick = {
                            navController.navigate("ChatScreen")
                        }) {
                            Icon(painter = painterResource(id = R.drawable.img_6), contentDescription = "Chat")
                        }
                        Text(text = "Chat", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        )
    }
}
