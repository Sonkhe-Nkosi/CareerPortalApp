package com.example.mycareerportalapp

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun AdminSignUpScreen(navController: NavController) {
    Scaffold(
        topBar = { AdminSignTopBar() },
        content = {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 100.dp)
            ) {
                item {
                    AdminSignUpForm(navController)
                }
            }
        }
    )
}

@Composable
fun AdminSignTopBar() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(240, 240, 241, 255))
            .padding(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
        ) {
            Image(
                painter = painterResource(id = R.drawable.logo), // Replace with your logo resource
                contentDescription = "Logo",
                modifier = Modifier.size(50.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Admin Portal",
                style = MaterialTheme.typography.titleMedium,
                color = Color(2, 24, 100, 255)
            )
        }
    }
}

@Composable
fun AdminSignUpForm(navController: NavController) {
    var emailAddress by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var staffNumber by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    var posts by remember { mutableStateOf<List<Map<String, Any>>>(emptyList()) }
    var selectedPost by remember { mutableStateOf<Map<String, Any>?>(null) }
    var approvalStatus by remember { mutableStateOf("Approved") }
    var saveFolder by remember { mutableStateOf("JobPosts") }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp) // Adjust horizontal padding as needed
    ) {
        TextField(
            value = emailAddress,
            onValueChange = { emailAddress = it },
            label = { Text("Email Address") },
            keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Email),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        TextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        TextField(
            value = confirmPassword,
            onValueChange = { confirmPassword = it },
            label = { Text("Confirm Password") },
            keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        TextField(
            value = staffNumber,
            onValueChange = { staffNumber = it },
            label = { Text("Staff/Student Number") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))

        // Signup button
        Button(
            onClick = {
                if (password == confirmPassword) {
                    adminSignUp(navController, emailAddress, password) { errorMessage = it }
                } else {
                    errorMessage = "Passwords do not match"
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
                .height(50.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(2, 24, 100, 255),
                contentColor = Color.White
            )
        ) {
            Text("Sign Up")
        }
        Spacer(modifier = Modifier.height(16.dp))

        // Retrieve Pending Posts button
        Button(
            onClick = {
                scope.launch {
                    retrievePendingPosts { retrievedPosts ->
                        posts = retrievedPosts
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
                .height(50.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(2, 24, 100, 255),
                contentColor = Color.White
            )
        ) {
            Text("Retrieve Pending Posts")
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Display retrieved posts and approve/reject
        posts.forEach { post ->
            PostItem(
                post = post,
                onApprove = { selectedPost = post; approvalStatus = "Approved" },
                onReject = { selectedPost = post; approvalStatus = "Rejected" }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Save to folder dropdown
        var expanded by remember { mutableStateOf(false) }
        Box {
            TextField(
                value = saveFolder,
                onValueChange = { saveFolder = it },
                label = { Text("Save To") },
                modifier = Modifier.fillMaxWidth(),
                trailingIcon = {
                    Icon(
                        painter = painterResource(id = R.drawable.img_7),
                        contentDescription = "Dropdown Icon",
                        modifier = Modifier.clickable { expanded = !expanded }
                    )
                }
            )
            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false },
                modifier = Modifier.fillMaxWidth()
            ) {
                listOf("JobPosts", "Learnerships", "Bursaries", "Internships", "Guidance").forEach { folder ->
                    DropdownMenuItem(onClick = {
                        saveFolder = folder
                        expanded = false
                    }) {
                        Text(folder)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Approve/Reject button
        Button(
            onClick = {
                selectedPost?.let { post ->
                    approveOrRejectPost(post, approvalStatus, saveFolder) { error ->
                        errorMessage = error
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
                .height(50.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(2, 24, 100, 255),
                contentColor = Color.White
            )
        ) {
            Text("Submit")
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Cancel button
        TextButton(
            onClick = { navController.popBackStack() },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Cancel")
        }

        // Show error message as snackbar
        errorMessage?.let { message ->
            Snackbar(
                action = {
                    TextButton(onClick = { errorMessage = null }) {
                        Text("OK")
                    }
                },
                modifier = Modifier.padding(16.dp)
            ) {
                Text(text = message)
            }
        }
    }
}

private fun adminSignUp(
    navController: NavController,
    email: String,
    password: String,
    setError: (String?) -> Unit
) {
    FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, password)
        .addOnCompleteListener { task ->
            if (task.isSuccessful) {
                // Sign up success
                navController.navigate("AdminLoginScreen")
            } else {
                // If sign up fails, handle the error
                val error = task.exception?.message ?: "Unknown error"
                setError(error)
            }
        }
}

private fun retrievePendingPosts(onResult: (List<Map<String, Any>>) -> Unit) {
    FirebaseFirestore.getInstance().collection("pendingPosts").get()
        .addOnSuccessListener { result ->
            val posts = result.documents.map { it.data ?: emptyMap() }
            onResult(posts)
        }
        .addOnFailureListener { exception ->
            // Handle any errors
            onResult(emptyList())
        }
}

private fun approveOrRejectPost(
    post: Map<String, Any>,
    approvalStatus: String,
    folder: String,
    setError: (String?) -> Unit
) {
    val db = FirebaseFirestore.getInstance()
    val pendingPostRef = db.collection("pendingPosts").document(post["id"] as String)

    if (approvalStatus == "Approved") {
        val destinationRef = db.collection(folder).document(post["id"] as String)
        destinationRef.set(post)
            .addOnSuccessListener {
                // Remove post from pendingPosts
                pendingPostRef.delete()
            }
            .addOnFailureListener { e ->
                setError("Failed to save approved post: ${e.message}")
            }
    } else {
        // Just remove post from pendingPosts
        pendingPostRef.delete()
            .addOnFailureListener { e ->
                setError("Failed to reject post: ${e.message}")
            }
    }
}

@Composable
fun PostItem(
    post: Map<String, Any>,
    onApprove: () -> Unit,
    onReject: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .background(Color.LightGray)
            .padding(16.dp)
    ) {
        Text(text = post["title"] as? String ?: "No Title")
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = post["description"] as? String ?: "No Description")
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(onClick = onApprove) {
                Text("Approve")
            }
            Button(onClick = onReject) {
                Text("Reject")
            }
        }
    }
}
