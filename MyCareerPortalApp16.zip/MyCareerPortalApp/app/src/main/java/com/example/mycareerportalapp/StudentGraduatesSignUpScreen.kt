package com.example.mycareerportalapp

import android.annotation.SuppressLint
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun StudentGraduatesSignUpScreen(navController: NavController) {
    Scaffold(
        topBar = { StudentGraduatesTopBar() },
        content = {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 100.dp)
            ) {
                item {
                    StudentGraduatesSignUpForm(navController)
                }
            }
        }
    )
}

@Composable
fun StudentGraduatesTopBar() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(240, 240, 241, 255))
            .padding(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
        ) {
            Image(
                painter = painterResource(id = R.drawable.logo), // Replace with your logo resource
                contentDescription = "Logo",
                modifier = Modifier.size(50.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "University of Mpumalanga Student & Graduates:",
                style = MaterialTheme.typography.titleLarge,
                color = Color(2, 24, 100, 255)
            )
        }
    }
}

@Composable
fun StudentGraduatesSignUpForm(navController: NavController) {
    var fullName by remember { mutableStateOf("") }
    var emailAddress by remember { mutableStateOf("") }
    var dateOfBirth by remember {mutableStateOf("") }
    var studentNumber by remember {mutableStateOf("") }
    var qualificationDestination by remember { mutableStateOf("") }
    var contactNumber by remember { mutableStateOf("") }
    var nationality by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var acceptTerms by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current

    Column(
        modifier = Modifier.fillMaxWidth()
    ) {
        Spacer(modifier = Modifier.height(16.dp))
        TextField(
            value = fullName,
            onValueChange = { fullName = it },
            label = { Text("Full Name") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        TextField(
            value = emailAddress,
            onValueChange = { emailAddress = it },
            label = { Text("Email Address") },
            keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Email),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))


        Spacer(modifier = Modifier.height(16.dp))
        TextField(
            value = contactNumber,
            onValueChange = { contactNumber = it },
            label = { Text("Contact Number") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        Modifier.fillMaxWidth().DateOfBirthPicker(
            dateOfBirth = remember { mutableStateOf("Date of Birth") }
        )

        Spacer(modifier = Modifier.height(16.dp))
        TextField(
            value = studentNumber,
            onValueChange = {},
            label = { Text("Student Number") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        TextField(
            value = qualificationDestination,
            onValueChange = {},
            label = { Text("Qualification Description") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        TextField(
            value = nationality,
            onValueChange = { nationality = it },
            label = { Text("Nationality") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        TextField(
            value = confirmPassword,
            onValueChange = { confirmPassword = it },
            label = { Text("Confirm Password") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))

        // Disclaimer message
        Text(
            text = "By signing up, you agree to our Terms and Conditions",
            style = MaterialTheme.typography.bodySmall,
            color = Color.Gray,
            textAlign = TextAlign.Start
        )
        Spacer(modifier = Modifier.height(16.dp))

        // Checkbox to accept terms and conditions
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = acceptTerms,
                onCheckedChange = { acceptTerms = it },
                colors = CheckboxDefaults.colors(checkedColor = Color(2, 24, 100, 255))
            )
            Text(
                text = "I accept the terms and conditions",
                style = MaterialTheme.typography.bodySmall
            )
        }
        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                if (password == confirmPassword) {
                    StudentGraduatesSignUp(
                        navController,
                        emailAddress,
                        password,
                        setError = { errorMessage = it })
                } else {
                    Toast.makeText(context, "Passwords do not match", Toast.LENGTH_SHORT).show()
                }
            },
            enabled = acceptTerms,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
                .height(50.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(2, 24, 100, 255),
                contentColor = Color.White
            )
        ) {
            Text("Sign Up")
        }
        Spacer(modifier = Modifier.height(16.dp))

        // Cancel button
        TextButton(
            onClick = { navController.popBackStack() },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Cancel")
        }
    }
}


private fun StudentGraduatesSignUp(
    navController: NavController,
    email: String,
    password: String,
    setError: (String?) -> Unit
) {
    FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, password)
        .addOnCompleteListener { task ->
            if (task.isSuccessful) {
                // Sign up success
                navController.navigate("StudentGraduatesLoginScreen")
            } else {
                // If sign up fails, handle the error
                val error = task.exception?.message ?: "Unknown error"
                setError(error)
            }
        }
}