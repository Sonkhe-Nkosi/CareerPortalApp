package com.example.mycareerportalapp

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun AlumniEmployerLoginScreen(navController: NavController) {
    // State to control showing alert dialog
    var showAlert by remember { mutableStateOf(false) }

    // State for email and password fields
    var emailState by remember { mutableStateOf("") }
    var passwordState by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.Top,
                        modifier = Modifier.padding(start = 8.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.logo),
                            contentDescription = null,
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .height(42.dp) // Ensure the Box is the same height as the logo
                                .border(1.dp, Color.Black)
                                .padding(horizontal = 16.dp)
                        ) {
                            Text(
                                text = "University of Mpumalanga:                 \n Alumni & Employer",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                lineHeight = 18.sp, // Adjust line height if necessary
                                modifier = Modifier.align(Alignment.Center)
                            )
                        }
                    }
                }
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 8.dp)
                .padding(top = 0.dp), // Add padding at the top
            verticalArrangement = Arrangement.Center, // Align content to the top
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
            Text(
                text = "Welcome back! [User]! Explore career opportunities, update your profile, and connect with peers.",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(vertical = 8.dp)
            )
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
            OutlinedTextField(
                value = emailState,
                onValueChange = { emailState = it },
                label = { Text("Email") },
                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
            )
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
            OutlinedTextField(
                value = passwordState,
                onValueChange = { passwordState = it },
                label = { Text("Password") },
                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
            )
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
            CustomButton(
                text = "Login",
                onClick = {
                    val email = emailState
                    val password = passwordState
                    // Call sign-in function with email and password when Login button is clicked
                    alumniEmployerSignIn(email, password, { showAlert = it }, navController)
                },
                modifier = Modifier
                    .width(400.dp) // Adjustable width
                    .height(50.dp) // Adjustable height
            )
            Spacer(modifier = Modifier.width(16.dp))
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
            CustomButton(
                text = "Sign Up",
                onClick = { navController.navigate("AlumniEmployerSignUpScreen") },
                modifier = Modifier
                    .width(400.dp) // Adjustable width
                    .height(50.dp) // Adjustable height
            )
            IconButton(
                onClick = { navController.popBackStack() },
                modifier = Modifier.padding(top = 16.dp)
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
            }
        }
    }
    if (showAlert) {
        AlertDialog(
            onDismissRequest = { showAlert = false },
            title = { Text(text = "Error") },
            text = { Text(text = "Incorrect email or password.") },
            confirmButton = {
                Button(onClick = { showAlert = false }) {
                    Text("OK")
                }
            }
        )
    }
}

// Example sign-in function, replace it with your actual implementation
fun alumniEmployerSignIn(email: String, password: String, showAlert: (Boolean) -> Unit, navController: NavController) {
    // Perform sign-in operation here
    // For example, you can use Firebase Authentication
    FirebaseAuth.getInstance().signInWithEmailAndPassword(email, password)
        .addOnCompleteListener { task ->
            if (task.isSuccessful) {
                // Sign in success, update UI with the signed-in user's information
                val user = FirebaseAuth.getInstance().currentUser
                navController.navigate("ApplicantDashboardScreen")
                // Update UI or navigate to another screen
            } else {
                // If sign in fails, display a message to the user.
                // Log.w("LoginActivity", "signInWithEmail:failure", task.exception)
                // Handle sign-in failure
                showAlert(true)
            }
        }
}
