package com.example.mycareerportalapp

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController

@Composable
fun DropdownMenuItem(
    onClick: () -> Unit,
    interactionSource: MutableInteractionSource = remember { MutableInteractionSource() },
    content: @Composable () -> Unit
) {
    val isPressed by interactionSource.collectIsPressedAsState()
    val backgroundColor = if (isPressed) Color(55, 156, 245, 255) else Color(55, 156, 245, 255)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(40.dp)
            .border(BorderStroke(1.dp, Color.Blue), shape = RoundedCornerShape(8.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .padding(8.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        content()
    }
}

@Composable
fun HomeScreen(navController: NavHostController) {
    var expanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Logo and Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = painterResource(id = R.drawable.logo), // Replace with your actual logo resource
                contentDescription = "Logo",
                modifier = Modifier.size(50.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Launch your career",
                fontSize = 20.sp
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Welcome Text
        Text(
            text = "Welcome!",
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Login As Text
        Text(
            text = "Login As:",
            fontSize = 20.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            CustomButton(
                text = "Administrator",
                onClick = { navController.navigate("AdminLoginScreen") },
                modifier = Modifier
                    .width(190.dp) // Adjustable width
                    .height(50.dp) // Adjustable height
            )
            CustomButton(
                text = "Applicant",
                onClick = { navController.navigate("ApplicantLoginScreen") },
                modifier = Modifier
                    .width(190.dp) // Adjustable width
                    .height(50.dp) // Adjustable height
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            CustomButton(
                text = "Graduate | Student",
                onClick = { navController.navigate("StudentGraduatesLoginScreen") },
                modifier = Modifier
                    .width(190.dp) // Adjustable width
                    .height(50.dp) // Adjustable height
            )
            CustomButton(
                text = "Alumni | Employer",
                onClick = { navController.navigate("AlumniEmployerLoginScreen") },
                modifier = Modifier
                    .width(190.dp) // Adjustable width
                    .height(50.dp) // Adjustable height
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Dropdown SignUp Button
        Box {
            CustomButton(
                text = "Sign Up",
                onClick = { expanded = true },
                modifier = Modifier
                    .width(380.dp) // Adjustable width
                    .height(50.dp) // Adjustable height
            )
            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                DropdownMenuItem(onClick = {
                    expanded = false
                    // Navigate to Applicant SignUp screen
                    navController.navigate("ApplicantSignUpScreen")
                }) {
                    Text("Applicant SignUp", color = Color(2, 24, 100, 255))
                }
                DropdownMenuItem(onClick = {
                    expanded = false
                    // Navigate to Graduate|Student SignUp screen
                    navController.navigate("StudentGraduatesSignUpScreen")
                }) {
                    Text("Graduate|Student SignUp", color = Color(2, 24, 100, 255))
                }
                DropdownMenuItem(onClick = {
                    expanded = false
                    // Navigate to Alumni|Employer|JobPoster SignUp screen
                    navController.navigate("AlumniEmployerSignUpScreen")
                }) {
                    Text("Alumni|Employer|JobPoster SignUp", color = Color(2, 24, 100, 255))
                }
            }
        }


    }
}

@Composable
fun CustomButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Color(0xFF021C5B),
            contentColor = Color.White
        )
    ) {
        Text(text)
    }
}
