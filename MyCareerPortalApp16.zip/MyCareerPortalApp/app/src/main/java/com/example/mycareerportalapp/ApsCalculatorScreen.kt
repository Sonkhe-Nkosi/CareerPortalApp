package com.example.mycareerportalapp

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun ApsCalculatorScreen(navController: NavController) {
    val context = LocalContext.current
    var selectedSubject by remember { mutableStateOf(subjectOptions[0]) }
    var marks by remember { mutableStateOf("") }
    var otherSubject by remember { mutableStateOf("") }
    var apsScore by remember { mutableStateOf(0) }
    val subjects = remember { mutableStateListOf<Pair<String, Int>>() }

    Scaffold(
        topBar = { ApsTopBar() },
        content = {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                item {
                    Text(
                        text = "Enter marks for each subject",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(vertical = 16.dp)
                    )
                }
                item {
                    Column {
                        SubjectDropdownMenu(
                            options = subjectOptions,
                            selectedOption = selectedSubject,
                            onOptionSelected = { selectedSubject = it }
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        if (selectedSubject == "Other" || selectedSubject == "Languages") {
                            TextField(
                                value = otherSubject,
                                onValueChange = { otherSubject = it },
                                label = { Text("Specify Subject") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp)
                            )
                        }
                        TextField(
                            value = marks,
                            onValueChange = {
                                if (it.toIntOrNull() in 1..7) {
                                    marks = it
                                } else if (it.isEmpty()) {
                                    marks = ""
                                }
                            },
                            label = { Text("Enter marks in levels 1-7") },
                            keyboardOptions = KeyboardOptions.Default.copy(
                                keyboardType = KeyboardType.Number
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                        )
                    }
                }
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 16.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        CustomButton(
                            text = "Add Subject",
                            onClick = {
                                val finalSubject = if (selectedSubject == "Other" || selectedSubject == "Languages") otherSubject else selectedSubject
                                if (subjects.size >= 7) {
                                    Toast.makeText(context, "You can only add up to 7 subjects", Toast.LENGTH_SHORT).show()
                                } else if (subjects.any { it.first == finalSubject }) {
                                    Toast.makeText(context, "Subject already added", Toast.LENGTH_SHORT).show()
                                } else if (finalSubject.isNotEmpty() && marks.isNotEmpty() && marks.toIntOrNull() != null && marks.toInt() in 1..7) {
                                    var finalMarks = marks.toInt()
                                    if (selectedSubject == "Life Orientation") {
                                        finalMarks /= 2
                                    }
                                    subjects.add(finalSubject to finalMarks)
                                    selectedSubject = subjectOptions[0]
                                    marks = ""
                                    otherSubject = ""
                                    Toast.makeText(context, "Subject added", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "Please select a subject and enter valid marks (1-7)", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier
                                .width(170.dp)
                                .height(50.dp)
                        )
                        CustomButton(
                            text = "Calculate APS",
                            onClick = {
                                apsScore = subjects.sumOf { it.second }
                                Toast.makeText(context, "APS Calculated", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier
                                .width(170.dp)
                                .height(50.dp)
                        )
                    }
                }
                item {
                    Text(
                        text = "Your Admission Point Score is: $apsScore",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(vertical = 16.dp)
                    )
                }
                items(subjects) { subject ->
                    SubjectItem(subject = subject.first, level = subject.second)
                }
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 16.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        CustomButton(
                            text = "Discover Courses",
                            onClick = { navController.navigate("StudentGraduatesLoginScreen") },
                            modifier = Modifier
                                .width(170.dp)
                                .height(50.dp)
                        )
                        CustomButton(
                            text = "Applications",
                            onClick = {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://ienabler.ump.ac.za/pls/prodi41/w99pkg.mi_login"))
                                context.startActivity(intent)
                            },
                            modifier = Modifier
                                .width(170.dp)
                                .height(50.dp)
                        )
                    }
                }
            }
        },
        bottomBar = {
            BottomBar(navController)
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApsTopBar() {
    TopAppBar(
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Image(
                    painter = painterResource(id = R.drawable.logo), // Replace with your logo resource
                    contentDescription = "Applicant Logo",
                    modifier = Modifier.size(40.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "APS Calculator",
                    style = MaterialTheme.typography.titleMedium,
                    color = Color(2, 24, 100, 255)
                )
            }
        }
    )
}

@Composable
fun BottomBar(navController: NavController) {
    BottomAppBar(
        content = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                IconButton(onClick = {
                    // Navigate to Home
                }) {
                    Icon(painter = painterResource(id = R.drawable.img_3), contentDescription = "Home")
                }
                IconButton(onClick = {
                    // Navigate to Profile
                }) {
                    Icon(painter = painterResource(id = R.drawable.img_4), contentDescription = "Profile")
                }
                IconButton(onClick = {
                    // Navigate to Courses
                }) {
                    Icon(painter = painterResource(id = R.drawable.img_5), contentDescription = "Courses")
                }
                IconButton(onClick = {
                    // Navigate to Chat
                }) {
                    Icon(painter = painterResource(id = R.drawable.img_6), contentDescription = "Chat")
                }
            }
        }
    )
}

@Composable
fun CustomButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    width: Dp = 100.dp,
    height: Dp = 50.dp,
    backgroundColor: Color = MaterialTheme.colorScheme.primary,
    contentColor: Color = Color.White
) {
    Button(
        onClick = onClick,
        modifier = modifier
            .width(width)
            .height(height),
        colors = ButtonDefaults.buttonColors(
            containerColor = backgroundColor,
            contentColor = contentColor
        )
    ) {
        Text(text = text)
    }
}

@Composable
fun SubjectDropdownMenu(
    options: List<String>,
    selectedOption: String,
    onOptionSelected: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxWidth()) {
        TextField(
            value = selectedOption,
            onValueChange = {},
            label = { Text("Select Subject") },
            modifier = Modifier.fillMaxWidth(),
            readOnly = true,
            trailingIcon = {
                IconButton(onClick = { expanded = true }) {
                    Icon(Icons.Default.ArrowDropDown, contentDescription = "Dropdown Arrow")
                }
            }
        )
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            options.forEach { option ->
                DropdownMenuItem(onClick = {
                    onOptionSelected(option)
                    expanded = false
                }) {
                    Text(text = option)
                }
            }
        }
    }
}

@Composable
fun SubjectItem(subject: String, level: Int) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = subject, style = MaterialTheme.typography.bodyMedium)
        Text(text = "Level: $level", style = MaterialTheme.typography.bodyMedium)
    }
}

val subjectOptions = listOf(
    "Math|Pure|Lit|Technical",
    "Physical Science",
    "CAT",
    "Life Orientation",
    "Languages",
    "Agricultural Science",
    "Life Science",
    "Business Studies",
    "History",
    "Geography",
    "Accounting",
    "Economics",
    "Other"
)