package com.example.mycareerportalapp

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun CustomButton(
    text: String,
    onClick: () -> Unit,
    navController: NavController? = null,
    destination: String? = null,
    modifier: Modifier = Modifier,
    width: Dp = ButtonDefaults.MinWidth,
    height: Dp = ButtonDefaults.MinHeight,
    isGoToChatButton: Boolean = false
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val indication = rememberRipple()

    Box(
        modifier = modifier
            .width(width)
            .height(height)
            .background(
                if (isPressed) Color(16, 105, 201, 255) else Color(2, 24, 100, 255),
                RoundedCornerShape(8.dp)
            )
            .clickable(
                indication = indication,
                interactionSource = interactionSource
            ) {
                if (isGoToChatButton) {
                    // Handle special behavior for Go To Chat button
                    onClick()
                } else {
                    destination?.let {
                        navController?.navigate(it)
                    }
                    onClick()
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = Color.White,
            style = MaterialTheme.typography.labelSmall
        )
    }
}
