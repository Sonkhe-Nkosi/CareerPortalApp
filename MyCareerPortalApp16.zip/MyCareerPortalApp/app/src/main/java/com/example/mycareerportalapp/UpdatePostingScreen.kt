package com.example.mycareerportalapp

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.tasks.await

@Composable
fun UpdatePostingScreen(navController: NavController) {
    var selectedFileUri by remember { mutableStateOf<Uri?>(null) }
    val context = LocalContext.current
    val firestore = FirebaseFirestore.getInstance()
    val storage = FirebaseStorage.getInstance()
    val database = FirebaseDatabase.getInstance("https://my-career-portal-app-default-rtdb.firebaseio.com/")

    var updateTitle by remember { mutableStateOf("") }
    var yourUpdate by remember { mutableStateOf("") }
    var attachFile by remember { mutableStateOf(false) }
    var fileType by remember { mutableStateOf("") }
    var dropdownExpanded by remember { mutableStateOf(false) }

    // File picker launcher for image and document
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            selectedFileUri = uri
        } else {
            Toast.makeText(context, "No file selected", Toast.LENGTH_SHORT).show()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        UpdatePostingTopBar()

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Update Title
            TextField(
                value = updateTitle,
                onValueChange = { updateTitle = it },
                label = { Text("Subject") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Description
            TextField(
                value = yourUpdate,
                onValueChange = { yourUpdate = it },
                label = { Text("Update") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Attach File Checkbox
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = attachFile,
                    onCheckedChange = { attachFile = it }
                )
                Text(text = "Attach File")
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (attachFile) {
                // File Type Dropdown
                Box {
                    Button(onClick = { dropdownExpanded = true }) {
                        Text("Select File Type")
                    }
                    DropdownMenu(
                        expanded = dropdownExpanded,
                        onDismissRequest = { dropdownExpanded = false }
                    ) {
                        DropdownMenuItem(onClick = { fileType = "Images"; dropdownExpanded = false }) {
                            Text("Image")
                        }
                        DropdownMenuItem(onClick = { fileType = "Documents"; dropdownExpanded = false }) {
                            Text("Document")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Upload File Button
                CustomButtonPosting(
                    text = "Upload File",
                    onClick = { filePickerLauncher.launch("*/*") }
                )

                Spacer(modifier = Modifier.height(16.dp))

                selectedFileUri?.let { uri ->
                    Text(
                        text = "Selected file: ${uri.path}",
                        color = Color.Gray,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Submit Button
            CustomButtonPosting(
                text = "Submit",
                onClick = {
                    if (updateTitle.isNotEmpty() && yourUpdate.isNotEmpty() &&
                        (!attachFile || (attachFile && selectedFileUri != null))) {
                        uploadFileAndData(
                            uri = selectedFileUri,
                            updateTitle = updateTitle,
                            yourUpdate = yourUpdate,
                            fileType = if (attachFile) fileType else null,
                            context = context,
                            navController = navController
                        )
                    } else {
                        Toast.makeText(context, "Please fill all fields", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
        }
    }
}

private fun uploadFileAndData(
    uri: Uri?,
    updateTitle: String,
    yourUpdate: String,
    fileType: String?,
    context: Context,
    navController: NavController
) {
    val database = FirebaseDatabase.getInstance("https://my-career-portal-app-default-rtdb.firebaseio.com/")
    val ref = database.reference.child("updates").push()

    if (uri != null) {
        val filePath = when (fileType) {
            "Images" -> "Images/${uri.lastPathSegment}"
            "Documents" -> "Documents/${uri.lastPathSegment}"
            else -> "Uploads/${uri.lastPathSegment}"
        }

        val storageRef = FirebaseStorage.getInstance().reference.child(filePath)

        storageRef.putFile(uri).addOnSuccessListener { taskSnapshot ->
            taskSnapshot.storage.downloadUrl.addOnSuccessListener { downloadUrl ->
                val data = mapOf(
                    "Title" to updateTitle,
                    "Update" to yourUpdate,
                    "FileUrl" to downloadUrl.toString(),
                    "Approved" to false
                )

                ref.setValue(data).addOnSuccessListener {
                    Toast.makeText(context, "Update Uploaded Successfully", Toast.LENGTH_SHORT).show()
                    navController.popBackStack()
                }.addOnFailureListener { e ->
                    Toast.makeText(context, "Failed to upload data: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }.addOnFailureListener { e ->
            Toast.makeText(context, "Failed to upload file: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    } else {
        val data = mapOf(
            "Title" to updateTitle,
            "Description" to yourUpdate,
            "Category" to "Updates",
            "Approved" to false
        )

        ref.setValue(data).addOnSuccessListener {
            Toast.makeText(context, "Update Uploaded Successfully", Toast.LENGTH_SHORT).show()
            navController.popBackStack()
        }.addOnFailureListener { e ->
            Toast.makeText(context, "Failed to upload data: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}

@Composable
fun UpdatePostingTopBar() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(240, 240, 241, 255))
            .padding(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Image(
                painter = painterResource(id = R.drawable.logo),
                contentDescription = "Logo",
                modifier = Modifier.size(50.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Share Update:",
                style = MaterialTheme.typography.titleMedium,
                color = Color(2, 24, 100, 255)
            )
        }
    }
}
