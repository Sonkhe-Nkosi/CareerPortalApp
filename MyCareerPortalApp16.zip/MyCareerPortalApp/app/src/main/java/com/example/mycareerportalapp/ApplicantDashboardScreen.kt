package com.example.mycareerportalapp

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.LocalImageLoader
import coil.compose.rememberImagePainter
import coil.request.ImageRequest
import com.google.accompanist.imageloading.LoadPainterDefaults
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ktx.getValue
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApplicantDashboardScreen(navController: NavController) {
    val coroutineScope = rememberCoroutineScope()
    var learnershipPosts by remember { mutableStateOf<List<learnershipPost>>(emptyList()) }
    var bursaryPosts by remember { mutableStateOf<List<bursaryPost>>(emptyList()) }
    var updatePosts by remember { mutableStateOf<List<updatePost>>(emptyList()) }
    var applicantLoading by remember { mutableStateOf(true) }
    var applicantRecentChats by remember { mutableStateOf<List<Chat>>(emptyList()) }

    LaunchedEffect(Unit) {
        coroutineScope.launch {
            learnershipPosts = fetchApprovedLearnershipPosts()
            bursaryPosts = fetchApprovedBursaryPosts()
            updatePosts = fetchApprovedUpdates()
            applicantRecentChats = fetchRecentChats()
            applicantLoading = false
        }
    }

    Scaffold(
        topBar = { ApplicantDashboardTopBar(navController) },
        bottomBar = { BottomNavigationBar(navController) },
        content = { paddingValues ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp)
            ) {
                item { Spacer(modifier = Modifier.height(16.dp)) }
                item { Learnerships(learnershipPosts) }
                item { Spacer(modifier = Modifier.height(16.dp)) }
                item { Bursaries(bursaryPosts) }
                item { Spacer(modifier = Modifier.height(16.dp)) }
                item { ActionButtons(navController) }
                item { UpdateProfileButton(navController) }
                item { TextTitle("Recent Chats") }
                item { HorizontalDivider() }
                items(applicantRecentChats) { chat ->
                    ChatItem(chat)
                }
                item { HorizontalDivider() }
                item { GoToChatButton(navController) }
                item { HorizontalDivider() }
                item { TextTitle("Updates") }
                item { HorizontalDivider() }
                item { OpportunitiesRow(updatePosts) }
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApplicantDashboardTopBar(navController: NavController) {
    TopAppBar(
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(
                    painter = painterResource(id = R.drawable.logo),
                    contentDescription = "Logo",
                    modifier = Modifier.size(50.dp)
                )
                var expanded by remember { mutableStateOf(false) }
                IconButton(onClick = { expanded = true }) {
                    Icon(painter = painterResource(id = R.drawable.img_7), contentDescription = "Menu")
                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        DropdownMenuItem(onClick = { navController.navigate("ApplicantDashboardScreen") }) { Text("Homepage") }
                        DropdownMenuItem(onClick = { navController.navigate("ApsCalculatorScreen") }) { Text("APS Calculator") }
                        DropdownMenuItem(onClick = { navController.navigate("DiscoverCoursesScreen") }) { Text("Find Course") }
                        DropdownMenuItem(onClick = { navController.navigate("SettingsScreen") }) { Text("Settings") }
                        DropdownMenuItem(onClick = { navController.navigate("MyProfileScreen") }) { Text("My Profile") }
                        DropdownMenuItem(onClick = {
                            FirebaseAuth.getInstance().signOut()
                            navController.navigate("ApplicantLoginScreen") {
                                popUpTo("ApplicantDashboardScreen") { inclusive = true }
                            }
                        }) { Text("Logout") }
                    }
                }
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = Color(240, 240, 241, 255),
            titleContentColor = Color(2, 24, 100, 255)
        )
    )
}

@Composable
fun Learnerships(posts: List<learnershipPost>) {
    Column {
        Text(
            text = "Learnerships",
            style = MaterialTheme.typography.headlineSmall.copy(fontSize = 20.sp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            textAlign = TextAlign.Start
        )
        LazyRow(
            modifier = Modifier.padding(bottom = 8.dp)
        ) {
            items(posts) { learnershipPost ->
                Column(
                    modifier = Modifier
                        .padding(end = 8.dp)
                        .width(200.dp)
                        .background(Color.LightGray)
                        .clip(RoundedCornerShape(10.dp))
                        .padding(8.dp)
                ) {
                    ImageCardWithOverlayText(
                        painter = rememberImagePainter(
                            data = learnershipPost.fileUrl
                           ),

                        contentDescription = learnershipPost.title
                    )
                    Text(
                        text = learnershipPost.title,
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                    Text(
                        text = learnershipPost.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                }
            }
        }
    }
}

@Composable
fun Bursaries(posts: List<bursaryPost>) {
    Column {
        Text(
            text = "Bursaries",
            style = MaterialTheme.typography.headlineSmall.copy(fontSize = 20.sp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            textAlign = TextAlign.Start
        )
        LazyRow(
            modifier = Modifier.padding(bottom = 8.dp)
        ) {
            items(posts) { bursaryPost ->
                Column(
                    modifier = Modifier
                        .padding(end = 8.dp)
                        .width(150.dp)
                ) {
                    ImageCardWithOverlayText(
                        painter = rememberImagePainter(
                            data = bursaryPost.fileUrl
                        ),
                        contentDescription = bursaryPost.title
                    )
                    Text(
                        text = bursaryPost.title,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                    Text(
                        text = bursaryPost.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                }
            }
        }
    }
}

@Composable
fun ActionButtons(navController: NavController) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        CustomButtonDashboard(
            text = "Discover Courses",
            onClick = { navController.navigate("DiscoverCoursesScreen") },
            modifier = Modifier
                .weight(1f)
                .padding(end = 8.dp)
        )
        CustomButtonDashboard(
            text = "Career Guidance",
            onClick = { navController.navigate("CareerGuidanceScreen") },
            modifier = Modifier
                .weight(1f)
                .padding(start = 8.dp)
        )
    }
}

@Composable
fun UpdateProfileButton(navController: NavController) {
    CustomButtonDashboard(
        text = "Update Profile",
        onClick = { navController.navigate("UpdateProfileScreen") },
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    )
}

@Composable
fun TextTitle(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.headlineSmall.copy(fontSize = 20.sp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        textAlign = TextAlign.Start
    )
}

@Composable
fun ChatItem(chat: Chat) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(
            painter = painterResource(id = R.drawable.logo), // Replace with your profile picture resource
            contentDescription = "Profile Picture",
            modifier = Modifier.size(50.dp)
        )
        Column(
            modifier = Modifier
                .padding(start = 8.dp)
                .weight(1f)
        ) {
            Text(text = chat.applicantName, style = MaterialTheme.typography.bodyLarge)
            Text(text = chat.applicantProfession, style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
            Text(text = chat.applicantLastMessage, style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
        }
        IconButton(onClick = { /* Handle chat item click */ }) {
            Icon(painter = painterResource(id = R.drawable.img_6), contentDescription = "Chat")
        }
    }
}

@Composable
fun GoToChatButton(navController: NavController) {
    CustomButtonDashboard(
        text = "Go to Chat",
        onClick = { navController.navigate("ChatScreen") },
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    )
}

@Composable
fun OpportunitiesRow(posts: List<updatePost>) {
    LazyRow {
        items(posts) { post ->
            Column(
                modifier = Modifier
                    .padding(end = 8.dp)
                    .width(150.dp)
                    .background(Color.LightGray)
                    .clip(RoundedCornerShape(10.dp))
                    .padding(8.dp)
            ) {
                ImageCardWithOverlayText(
                    painter = rememberImagePainter(
                        data = post.fileUrl,
                        imageLoader = LocalImageLoader.current
                    ),
                    contentDescription = post.title
                )
                Text(
                    text = post.title,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}

@Composable
fun CustomButtonDashboard(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Button(
        onClick = onClick,
        modifier = modifier,
        colors = ButtonDefaults.buttonColors(containerColor = Color(2, 24, 100, 255))
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.bodyLarge.copy(color = Color.White)
        )
    }
}

@Composable
fun ImageCardWithOverlayText(painter: Painter, contentDescription: String) {
    Box(
        modifier = Modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(10.dp))
            .background(Color.Black)
            .border(1.dp, Color.Gray, RoundedCornerShape(10.dp))
    ) {
        Image(
            painter = painter,
            contentDescription = contentDescription,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
fun HorizontalDivider() {
    Divider(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .background(Color.LightGray),
        thickness = 1.dp
    )
}



data class updatePost(
    val title: String = "",
    val fileUrl: String = ""
)

data class Chat(
    val applicantName: String = "",
    val applicantProfession: String = "",
    val applicantLastMessage: String = ""
)

// Firebase Functions
suspend fun fetchApprovedLearnershipPosts(): List<learnershipPost> {
    return try {
        val database = FirebaseDatabase.getInstance("https://my-career-portal-app-default-rtdb.firebaseio.com/").reference
        val snapshot = database.child("approvedLearnershipPosts").get().await()
        if (snapshot.exists()) {
            snapshot.children.mapNotNull { it.getValue(learnershipPost::class.java) }
        } else {
            emptyList()
        }
    } catch (e: Exception) {
        emptyList()
    }
}

suspend fun fetchApprovedBursaryPosts(): List<bursaryPost> {
    return try {
        val database = FirebaseDatabase.getInstance("https://my-career-portal-app-default-rtdb.firebaseio.com/").reference
        val snapshot = database.child("approvedBursaryPosts").get().await()
        if (snapshot.exists()) {
            snapshot.children.mapNotNull { it.getValue(bursaryPost::class.java) }
        } else {
            emptyList()
        }
    } catch (e: Exception) {
        emptyList()
    }
}

suspend fun fetchApprovedUpdates(): List<updatePost> {
    return try {
        val database = FirebaseDatabase.getInstance("https://my-career-portal-app-default-rtdb.firebaseio.com/").reference
        val snapshot = database.child("approvedUpdates").get().await()
        if (snapshot.exists()) {
            snapshot.children.mapNotNull { it.getValue(updatePost::class.java) }
        } else {
            emptyList()
        }
    } catch (e: Exception) {
        emptyList()
    }
}

suspend fun fetchRecentChats(): List<Chat> {
    return try {
        val database = FirebaseDatabase.getInstance("https://my-career-portal-app-default-rtdb.firebaseio.com/").reference
        val userId = FirebaseAuth.getInstance().currentUser?.uid ?: ""
        val snapshot = database.child("chats").child(userId).get().await()
        if (snapshot.exists()) {
            snapshot.children.mapNotNull { it.getValue(Chat::class.java) }
        } else {
            emptyList()
        }
    } catch (e: Exception) {
        emptyList()
    }
}
@Composable
fun BottomNavigationBar(navController: NavController) {
    var expanded by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color.Black, shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
            .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
    ) {
        BottomAppBar(
            content = {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(6.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        IconButton(onClick = {
                            navController.navigate("ApplicantDashboardScreen")
                        }) {
                            Icon(painter = painterResource(id = R.drawable.img_3), contentDescription = "Home")
                        }
                        Text(text = "Home", style = MaterialTheme.typography.labelMedium)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        IconButton(onClick = {
                            navController.navigate("MyProfileScreen")
                        }) {
                            Icon(painter = painterResource(id = R.drawable.img_4), contentDescription = "Profile")
                        }
                        Text(text = "Profile", style = MaterialTheme.typography.labelMedium)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        // Dropdown Button
                        Box {
                            IconButton(onClick = { expanded = !expanded }) {
                                Icon(painter = painterResource(id = R.drawable.addbuttonicon), contentDescription = "Add Post")
                            }
                            DropdownMenu(
                                expanded = expanded,
                                onDismissRequest = { expanded = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Bursary") },
                                    onClick = {
                                        expanded = false
                                        navController.navigate("BursaryPostingScreen")
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Learnership") },
                                    onClick = {
                                        expanded = false
                                        navController.navigate("LearnershipPostingScreen")
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Job") },
                                    onClick = {
                                        expanded = false
                                        navController.navigate("JobPostingScreen")
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Internship") },
                                    onClick = {
                                        expanded = false
                                        navController.navigate("InternshipPostingScreen")
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Updates") },
                                    onClick = {
                                        expanded = false
                                        navController.navigate("UpdatePostingScreen")
                                    }
                                )
                            }
                        }
                        Text(text = "Add", style = MaterialTheme.typography.labelMedium)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        IconButton(onClick = {
                            navController.navigate("ApsCalculatorScreen")
                        }) {
                            Icon(painter = painterResource(id = R.drawable.apscalculator), contentDescription = "Calculate APS")
                        }
                        Text(text = "Aps", style = MaterialTheme.typography.labelMedium)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        IconButton(onClick = {
                            navController.navigate("ChatScreen")
                        }) {
                            Icon(painter = painterResource(id = R.drawable.img_6), contentDescription = "Chat")
                        }
                        Text(text = "Chat", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        )
    }
}