package com.example.mycareerportalapp

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.tasks.await

@Composable
fun LearnershipPostingScreen(navController: NavController) {
    var selectedFileUri by remember { mutableStateOf<Uri?>(null) }
    val context = LocalContext.current
    val firestore = FirebaseFirestore.getInstance()
    val storage = FirebaseStorage.getInstance()
    val database = FirebaseDatabase.getInstance("https://my-career-portal-app-default-rtdb.firebaseio.com/")

    // State to manage dropdown visibility and checkbox
    var dropdownExpanded by remember { mutableStateOf(false) }
    var attachFile by remember { mutableStateOf(false) }

    // File picker launcher for image and document
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent(),
        onResult = { uri ->
            if (uri != null) {
                selectedFileUri = uri
            } else {
                Toast.makeText(context, "No file selected", Toast.LENGTH_SHORT).show()
            }
        }
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        LearnershipPostingTopBar()

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            var learnershipTitle by remember { mutableStateOf("") }
            var learnershipName by remember { mutableStateOf("") }
            var learnershipDescription by remember { mutableStateOf("") }
            var learnershipRequirements by remember { mutableStateOf("") }
            var learnershipLocation by remember { mutableStateOf("") }
            var fileType by remember { mutableStateOf("") }

            // Title
            TextField(
                value = learnershipTitle,
                onValueChange = { learnershipTitle = it },
                label = { Text("Title") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Organization Name
            TextField(
                value = learnershipName,
                onValueChange = { learnershipName = it },
                label = { Text("Organization Name") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Description
            TextField(
                value = learnershipDescription,
                onValueChange = { learnershipDescription = it },
                label = { Text("Description") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Requirements
            TextField(
                value = learnershipRequirements,
                onValueChange = { learnershipRequirements = it },
                label = { Text("Requirements") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Location
            TextField(
                value = learnershipLocation,
                onValueChange = { learnershipLocation = it },
                label = { Text("Location") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Attach File Checkbox
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = attachFile,
                    onCheckedChange = { attachFile = it }
                )
                Text(text = "Attach File")
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (attachFile) {
                // File Type Dropdown
                Box {
                    DropdownMenu(
                        expanded = dropdownExpanded,
                        onDismissRequest = { dropdownExpanded = false },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        DropdownMenuItem(onClick = { fileType = "Images"; dropdownExpanded = false }) {
                            Text("Image")
                        }
                        DropdownMenuItem(onClick = { fileType = "Documents"; dropdownExpanded = false }) {
                            Text("Document")
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }

                // Upload File Button
                CustomButtonPosting(
                    text = "Upload File",
                    onClick = { filePickerLauncher.launch("*/*") }
                )

                Spacer(modifier = Modifier.height(16.dp))

                selectedFileUri?.let { uri ->
                    Text(
                        text = "Selected file: ${uri.path}",
                        color = Color.Gray,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
            }

            CustomButtonPosting(
                text = "Submit",
                onClick = {
                    if (!attachFile || (attachFile && selectedFileUri != null)) {
                        uploadFileAndData(
                            uri = selectedFileUri,
                            learnershipTitle = learnershipTitle,
                            learnershipName = learnershipName,
                            learnershipDescription = learnershipDescription,
                            learnershipRequirements = learnershipRequirements,
                            learnershipLocation = learnershipLocation,
                            fileType = if (attachFile) fileType else null,
                            category = "Learnerships",
                            context = context,
                            navController = navController
                        )
                    } else {
                        Toast.makeText(context, "Empty Field", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
        }
    }
}

private fun uploadFileAndData(
    uri: Uri?,
    learnershipTitle: String,
    learnershipName: String,
    learnershipDescription: String,
    learnershipRequirements: String,
    learnershipLocation: String,
    fileType: String?,
    category: String,
    context: Context,
    navController: NavController
) {
    val database = FirebaseDatabase.getInstance("https://my-career-portal-app-default-rtdb.firebaseio.com/")
    val ref = database.reference.child("pendingLearnershipPosts").push()


    if (uri != null) {
        val filePath = when (fileType) {
            "Images" -> "Images/${uri.lastPathSegment}"
            "Documents" -> "Documents/${uri.lastPathSegment}"
            else -> "Uploads/${uri.lastPathSegment}"
        }

        val storageRef = FirebaseStorage.getInstance().reference.child(filePath)

        storageRef.putFile(uri).addOnSuccessListener { taskSnapshot ->
            taskSnapshot.storage.downloadUrl.addOnSuccessListener { downloadUrl ->
                val data = mapOf(
                    "Title" to learnershipTitle,
                    "Name" to learnershipName,
                    "Description" to learnershipDescription,
                    "Requirements" to learnershipRequirements,
                    "Location" to learnershipLocation,
                    "FileUrl" to downloadUrl.toString(),
                    "Category" to category,
                    "Approved" to false
                )

                ref.setValue(data).addOnSuccessListener {
                    Toast.makeText(context, "Post Uploaded Successfully", Toast.LENGTH_SHORT).show()
                    navController.popBackStack()
                }.addOnFailureListener { e ->
                    Toast.makeText(context, "Failed to upload data: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }.addOnFailureListener { e ->
            Toast.makeText(context, "Failed to upload file: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    } else {
        val data = mapOf(
            "Title" to learnershipTitle,
            "Name" to learnershipName,
            "Description" to learnershipDescription,
            "Requirements" to learnershipRequirements,
            "Location" to learnershipLocation,
            "Category" to category,
            "Approved" to false
        )

        ref.setValue(data).addOnSuccessListener {
            Toast.makeText(context, "Post Uploaded Successfully", Toast.LENGTH_SHORT).show()
            navController.popBackStack()
        }.addOnFailureListener { e ->
            Toast.makeText(context, "Failed to upload data: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}

@Composable
fun LearnershipPostingTopBar() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(240, 240, 241, 255))
            .padding(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Image(
                painter = painterResource(id = R.drawable.logo),
                contentDescription = "Logo",
                modifier = Modifier.size(50.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Share Learnership Opportunity:",
                style = MaterialTheme.typography.titleMedium,
                color = Color(2, 24, 100, 255)
            )
        }
    }
}
