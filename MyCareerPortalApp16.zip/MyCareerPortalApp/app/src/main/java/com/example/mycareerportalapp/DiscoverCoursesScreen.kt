package com.example.mycareerportalapp

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiscoverCoursesScreen(navController: NavController) {
    Scaffold(
        topBar = { GenericTopBar(navController, "Discover Courses") },
        bottomBar = { BottomNavigationBar(navController) },
        content = { paddingValues ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp)
            ) {
                item { Text("Discover Courses Content", style = MaterialTheme.typography.bodyLarge) }
            }
        }
    )
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GenericTopBar(navController: NavController, title: String) {
    TopAppBar(
        title = { Text(title, color = Color.Black) },
        navigationIcon = {
            IconButton(onClick = { navController.popBackStack() }) {
                Icon(painter = painterResource(id = R.drawable.back_arrow), contentDescription = "Back")
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = Color(240, 240, 241, 255),
            titleContentColor = Color(2, 24, 100, 255)
        )
    )
}