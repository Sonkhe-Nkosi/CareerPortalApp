package com.example.mycareerportalapp

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import com.google.firebase.firestore.FirebaseFirestore

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun AdminDashboardScreen(navController: NavController) {
    var expanded by remember { mutableStateOf(false) }
    var newLearnershipPosts by remember { mutableStateOf<List<learnershipPost>>(emptyList()) }
    var newBursaryPosts by remember { mutableStateOf<List<bursaryPost>>(emptyList()) }
    var newInternshipPosts by remember { mutableStateOf<List<internshipPost>>(emptyList()) }
    var newUpdatePosts by remember { mutableStateOf<List<updatePost>>(emptyList()) }
    val context = LocalContext.current
    val database = Firebase.database("https://my-career-portal-app-default-rtdb.firebaseio.com/").reference

    LaunchedEffect(Unit) {
        val pendingCollections = listOf(
            "updates",
            "pendingLearnershipPosts",
            "pendingInternshipPosts",
            "pendingBursaryPosts",
            "pendingJobPosts"
        )

        val allPosts = mutableListOf<learnershipPost>()
        pendingCollections.forEach { collection ->
            database.child(collection).get().addOnSuccessListener { snapshot ->
                val posts = snapshot.children.mapNotNull { dataSnapshot ->
                    val post = dataSnapshot.getValue(learnershipPost::class.java)
                    post?.copy(learnershipID = dataSnapshot.key ?: "", category = collection)
                }
                allPosts.addAll(posts)
                newLearnershipPosts = allPosts
            }.addOnFailureListener { e ->
                Toast.makeText(context, "Error fetching posts from $collection: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Scaffold(
        topBar = { AdminDashboardTopBar() },
        floatingActionButton = {
            Box {
                FloatingActionButton(onClick = { expanded = true }) {
                    Icon(painterResource(id = R.drawable.addbuttonicon), contentDescription = "Create Post")
                }
                DropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("Bursary") },
                        onClick = {
                            expanded = false
                            navController.navigate("BursaryPostingScreen")
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Learnership") },
                        onClick = {
                            expanded = false
                            navController.navigate("LearnershipPostingScreen")
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Scholarship") },
                        onClick = {
                            expanded = false
                            navController.navigate("InternshipPostingScreen")
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Job") },
                        onClick = {
                            expanded = false
                            navController.navigate("JobPostingScreen")
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Updates") },
                        onClick = {
                            expanded = false
                            navController.navigate("UpdatesPostingScreen")
                        }
                    )
                }
            }
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Text("Admin Dashboard", style = MaterialTheme.typography.headlineMedium)
            Button(
                onClick = {
                    val url = "https://console.firebase.google.com/" // Firebase Console URL
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                    context.startActivity(intent)
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6200EE)),
                modifier = Modifier.padding(vertical = 8.dp)
            ) {
                Text(
                    text = "Go to Database",
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }
            LazyColumn {
                items(newLearnershipPosts) { learnershipPost ->
                    PostItem(post = learnershipPost(), navController = navController)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardTopBar() {
    TopAppBar(
        title = { Text("Admin Dashboard") },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = Color(240, 240, 241, 255)
        )
    )
}

@Composable
fun PostItem(post: learnershipPost, navController: NavController) {
    var expanded by remember { mutableStateOf(false) }
    var showDialog by remember { mutableStateOf(false) }

    Column(modifier = Modifier.padding(8.dp)) {
        Text(post.title, style = MaterialTheme.typography.titleLarge)
        Text("Name: ${post.name}", style = MaterialTheme.typography.bodyMedium)
        Text("Location: ${post.location}", style = MaterialTheme.typography.bodyMedium)

        Row {
            Button(onClick = { expanded = !expanded }) {
                Text(if (expanded) "Hide Details" else "Show Details")
            }
            Spacer(modifier = Modifier.width(8.dp))
            Button(onClick = { showDialog = true }) {
                Text("Approve/Reject")
            }
        }

        if (expanded) {
            Text("Description: ${post.description}", style = MaterialTheme.typography.bodyMedium)
            Text("Requirements: ${post.requirements}", style = MaterialTheme.typography.bodyMedium)
            Text("File URL: ${post.fileUrl}", style = MaterialTheme.typography.bodyMedium)
        }

        if (showDialog) {
            ApproveRejectDialog(
                post = post,
                onDismiss = { showDialog = false },
                navController = navController
            )
        }
    }
}

@Composable
fun ApproveRejectDialog(post: learnershipPost, onDismiss: () -> Unit, navController: NavController) {
    var selectedOptions by remember { mutableStateOf(setOf<String>()) }
    val context = LocalContext.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Approve or Reject Post") },
        text = {
            Column {
                Text("To which dashboard does this post belong?")
                val options = listOf("Applicants", "Students", "Alumni")
                options.forEach { option ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = selectedOptions.contains(option),
                            onCheckedChange = { isChecked ->
                                selectedOptions = if (isChecked) {
                                    selectedOptions + option
                                } else {
                                    selectedOptions - option
                                }
                            }
                        )
                        Text(option)
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                approvePost(post, selectedOptions, navController, context)
                onDismiss()
            }) {
                Text("Approve")
            }
        },
        dismissButton = {
            Button(onClick = {
                rejectPost(post, context)
                onDismiss()
            }) {
                Text("Reject")
            }
        }
    )
}

private fun approvePost(post: learnershipPost, selectedOptions: Set<String>, navController: NavController, context: Context) {
    val database = Firebase.database("https://my-career-portal-app-default-rtdb.firebaseio.com/").reference

    // Map the category to the appropriate approved collection
    val approvedCollection = when (post.category) {
        "updates" -> "approvedUpdates"
        "pendingLearnershipPosts" -> "approvedLearnershipPosts"
        "pendingInternshipPosts" -> "approvedInternshipPosts"
        "pendingBursaryPosts" -> "approvedBursaryPosts"
        "pendingJobPosts" -> "approvedJobPosts"
        else -> {
            Toast.makeText(context, "Unknown category: ${post.category}", Toast.LENGTH_SHORT).show()
            return
        }
    }

    // Approve the post by moving it to the appropriate collection
    database.child(approvedCollection).child(post.learnershipID).setValue(post)
        .addOnSuccessListener {
            database.child(post.category).child(post.learnershipID).removeValue()
            Toast.makeText(context, "Post approved and moved to $approvedCollection", Toast.LENGTH_SHORT).show()
            navController.popBackStack()
        }
        .addOnFailureListener { e ->
            Toast.makeText(context, "Error approving post: ${e.message}", Toast.LENGTH_SHORT).show()
        }
}

private fun rejectPost(post: learnershipPost, context: Context) {
    val database = Firebase.database("https://my-career-portal-app-default-rtdb.firebaseio.com/").reference

    // Reject the post by removing it from the current collection
    database.child(post.category).child(post.learnershipID).removeValue()
        .addOnSuccessListener {
            Toast.makeText(context, "Post rejected and removed", Toast.LENGTH_SHORT).show()
        }
        .addOnFailureListener { e ->
            Toast.makeText(context, "Error rejecting post: ${e.message}", Toast.LENGTH_SHORT).show()
        }
}

data class learnershipPost(
    val learnershipID: String = "",
    val title: String = "",
    val name: String = "",
    val description: String = "",
    val requirements: String = "",
    val location: String = "",
    val fileUrl: String? = null,
    val category: String = "pendingLearnershipPosts",
    val approved: Boolean = false
)

data class internshipPost(
    val title: String = "",
    val name: String = "",
    val description: String = "",
    val requirements: String = "",
    val location: String = "",
    val fileUrl: String = "",
    val learnershipID: String = "",
    val approved: Boolean = false
)
